# Checklist de publicação e monetização

1. Substitua `SEU-DOMINIO.com` em `index.html`, páginas, `robots.txt` e `sitemap.xml`.
2. Publique o conteúdo de `index.html` na raiz do domínio.
3. Confirme HTTPS, redirecionamento de HTTP para HTTPS e versão canônica única.
4. Troque `G-XXXXXXXXXX` pelo ID real do Google Analytics.
5. Crie e verifique a propriedade no Google Search Console e envie `/sitemap.xml`.
6. Cadastre o site em uma rede de anúncios compatível e só depois troque os placeholders de anúncios.
7. Publique uma política de privacidade, termos e contato com dados reais.
8. Teste no celular: calculadoras, copiar resultado, favoritos, histórico, modo escuro e links internos.
9. Não coloque anúncios sobre botões, resultados ou campos de entrada.
10. Monitore erros 404, páginas indexadas, consultas de busca e receita antes de ampliar o inventário de anúncios.
